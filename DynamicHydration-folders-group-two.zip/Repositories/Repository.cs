﻿using Dapper;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicHydration.Repositories
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        private IDbTransaction _transaction;
        private IDbConnection _connection;

        public Repository(IDbTransaction transaction, IDbConnection dbConnection)
        {
            _transaction = transaction;
            _connection = dbConnection;
        }

        public T ExecuteScalar<T>(string sql, object param)
        {
            return _connection.ExecuteScalar<T>(sql, param, _transaction);
        }

        public T QuerySingleOrDefault<T>(string sql, object param)
        {
            return _connection.QuerySingleOrDefault<T>(sql, param, _transaction);
        }

        public async Task<T> QuerySingleOrDefaultAsync<T>(string sql, object param)
        {
            return await _connection.QuerySingleOrDefaultAsync<T>(sql, param, _transaction);
        }

        public HashSet<T> QueryMultiple<T>(string sql, object param)
        {
            try
            {
                var result = _connection.QueryMultiple(sql, param: param, transaction: _transaction, commandType: CommandType.StoredProcedure);
                var data = result.Read<T>().ToHashSet();
                return data;
            }
            catch (Exception ex)
            {
                _transaction.Rollback();
            }
            finally
            {
                //_transaction.Dispose();
                ////_connection = new SqlConnection(_connectionString);
                ////_connection.Open();
                //_transaction = _connection.BeginTransaction();
            }
            return new HashSet<T>();
        }

        public async Task<HashSet<T>> QueryMultipleAsync<T>(string sql, object param)
        {
            try
            {
                var result = await _connection.QueryMultipleAsync(sql, param: param, transaction: _transaction, commandType: CommandType.StoredProcedure);
                var data = result.ReadAsync<T>().Result.ToHashSet();
                return data;
            }
            catch (Exception ex)
            {
                _transaction.Rollback();
            }
            finally
            {
                //_transaction.Dispose();
                ////_connection = new SqlConnection(_connectionString);
                ////_connection.Open();
                //_transaction = _connection.BeginTransaction();
            }
            return new HashSet<T>();
        }

        public HashSet<int> QueryMultipleInt<T>(string sql, object param)
        {
            try
            {
                var result = _connection.QueryMultiple(sql, param: param, transaction: _transaction, commandType: CommandType.StoredProcedure);
                var data = result.Read<int>().ToHashSet();
                return data;
            }
            catch (Exception ex)
            {
                _transaction.Rollback();
            }
            finally
            {
                //_transaction.Dispose();
                ////_connection = new SqlConnection(_connectionString);
                ////_connection.Open();
                //_transaction = _connection.BeginTransaction();
            }
            return new HashSet<int>();
        }

        public async Task<HashSet<int>> QueryMultipleIntAsync<T>(string sql, object param)
        {
            try
            {
                var result = await _connection.QueryMultipleAsync(sql, param: param, transaction: _transaction, commandType: CommandType.StoredProcedure);
                var data = result.ReadAsync<int>().Result.ToHashSet();
                return data;
            }
            catch (Exception ex)
            {
                _transaction.Rollback();
            }
            finally
            {
                //_transaction.Dispose();
                ////_connection = new SqlConnection(_connectionString);
                ////_connection.Open();
                //_transaction = _connection.BeginTransaction();
            }
            return new HashSet<int>();
        }
        public T QueryFirstOrDefault<T>(string sql, object param)
        {
            return _connection.QueryFirstOrDefault<T>(sql, param, _transaction);
        }

        public async Task<T> QueryFirstOrDefaultAsync<T>(string sql, object param)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(sql, param, _transaction);
        }

        public IEnumerable<T> Query<T>(string sql, object param = null)
        {
            return _connection.Query<T>(sql, param, _transaction);
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null)
        {
            return await _connection.QueryAsync<T>(sql, param, _transaction);
        }

        public void Execute(string sql, object param)
        {
            _connection.Execute(sql, param, _transaction);
        }

        public void ExecuteAsync(string sql, object param)
        {
            _connection.ExecuteAsync(sql, param, _transaction);
        }

        public long Insert(TEntity obj, int timeout = 1500)
        {
            return _connection.Insert<TEntity>(obj, _transaction, timeout);
        }

        public async Task<long> InsertAsync(TEntity obj, int timeout = 1500)
        {
            return await _connection.InsertAsync<TEntity>(obj, _transaction, timeout);
        }

        public bool Update(TEntity obj, int timeout = 1500)
        {
            return _connection.Update<TEntity>(obj, _transaction, timeout);
        }

        public async Task<bool> UpdateAsync(TEntity obj, int timeout = 1500)
        {
            return await _connection.UpdateAsync<TEntity>(obj, _transaction, timeout);
        }
    }
}
