﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DynamicHydration.Repositories
{
    public interface IRepository<TEntity> where TEntity : class
    {
        T ExecuteScalar<T>(string sql, object param);
        T QueryFirstOrDefault<T>(string sql, object param);
        Task<T> QueryFirstOrDefaultAsync<T>(string sql, object param);
        T QuerySingleOrDefault<T>(string sql, object param);
        Task<T> QuerySingleOrDefaultAsync<T>(string sql, object param);
        HashSet<T> QueryMultiple<T>(string sql, object param);
        Task<HashSet<T>> QueryMultipleAsync<T>(string sql, object param);
        HashSet<int> QueryMultipleInt<T>(string sql, object param);
        Task<HashSet<int>> QueryMultipleIntAsync<T>(string sql, object param);
        IEnumerable<T> Query<T>(string sql, object param = null);
        Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null);
        void Execute(string sql, object param);
        void ExecuteAsync(string sql, object param);
        long Insert(TEntity obj, int timeout = 1500);
        Task<long> InsertAsync(TEntity obj, int timeout = 1500);
        bool Update(TEntity obj, int timeout = 1500);
        Task<bool> UpdateAsync(TEntity obj, int timeout = 1500);
    }
}
