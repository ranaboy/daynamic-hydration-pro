﻿using DynamicHydration.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace DynamicHydration.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
        IRepository<T> Repository<T>() where T : class;
    }
}