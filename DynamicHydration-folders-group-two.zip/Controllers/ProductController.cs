﻿using DynamicHydration.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace DynamicHydration.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService productService;

        //public ProductController(IProductService productService)
        //{
        //    this.productService = productService;
        //}

        // GET: Product
        public ActionResult Index()
        {
            return View();
        }

        // GET: Product
        public ActionResult DataTable()
        {
            return View();
        }
        public ActionResult AddProduct()
        {
            return View();
        }
        public ActionResult AddNewEnvironmentParameter()
        {
            return View();
        }

        [HttpGet]
        [Route("GetAllProducts")]
        public async Task<ActionResult> ProductsList()
        {
            var products = await this.productService.GetAllProductsAsync();
            return View(products);
        }
        //[HttpGet]
        //[Route("GetProductById")]
        //public async Task<ActionResult> GetProductById(int id)
        //{
        //    var products = await this.productService.GetProductByIdAsync(id);
        //    return View(products);
        //}
    }
}