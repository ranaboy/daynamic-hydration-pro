﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicHydration.Models.Response
{
    public class ProductResponse
    {
        public int Id { get; set; }
        public string ProductCD { get; set; }
        public string ProductDesc { get; set; }
        public bool ActiveFlag { get; set; }
    }
}