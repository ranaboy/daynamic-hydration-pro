﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicHydration.Models.UpdateRequest
{
    public class ProductUpdateRequest
    {
        public string ProductCD { get; set; }
        public string ProductDesc { get; set; }
        public bool ActiveFlag { get; set; }

    }
}