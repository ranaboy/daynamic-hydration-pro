﻿using AutoMapper;
using Dapper;
using DynamicHydration.Models.Request;
using DynamicHydration.Models.Response;
using DynamicHydration.Services.Interface;
using DynamicHydration.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DynamicHydration.Services.Implementation
{
    public class ProductService : IProductService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper mapper;

        public ProductService(
            IUnitOfWork unitOfWork,
            IMapper mapper
            )
        {
            this._unitOfWork = unitOfWork;
            this.mapper = mapper;
        }

        public async Task<List<ProductResponse>> GetAllProductsAsync()
        {
            //var param = new DynamicParameters();
            //param.Add("ProductId", id, DbType.Int32);

            var sql = "Select * from Product";
            var getLookups = await _unitOfWork.Repository<Product>().QueryAsync<Product>(sql);
            var response = this.mapper.Map<List<ProductResponse>>(getLookups);
            return response;
        }
        public async Task<ProductResponse> GetProductByIdAsync(int id)
        {
            var param = new DynamicParameters();
            param.Add("ProductId", id, DbType.Int32);

            var sql = "Select * from Product";
            var getLookups = await _unitOfWork.Repository<Product>().QueryAsync<Product>(sql, param);
            var response = this.mapper.Map<ProductResponse>(getLookups);
            return response;
        }
        public async Task<ProductResponse> AddProductAsync(ProductRequest productRequest)
        {
            var product = new Product();
            if(productRequest != null)
            {
                product.ProductCD = productRequest.ProductCD;
                product.ProductDesc = productRequest.ProductDesc;
                product.ActiveFlag = productRequest.ActiveFlag;
                //await this._unitOfWork.Repository<Product>().Add(product);
                //await this._unitOfWork.
            }

            return null;
        }
    }
}