﻿using AutoMapper;
using DynamicHydration.Models.Request;
using DynamicHydration.Models.Response;
using DynamicHydration.Models.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicHydration
{
    public class AutoMapperConfiguration : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperConfiguration"/> class.
        /// </summary>
        public AutoMapperConfiguration()
        {
            CreateMap<Product, ProductResponse>().ReverseMap();
            CreateMap<Product, ProductRequest>().ReverseMap();
            CreateMap<Product, ProductUpdateRequest>().ReverseMap();
        }

    }
}